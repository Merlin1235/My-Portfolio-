# Hi, I'm Joseph Musyimi Kala 👋

**Software Developer | Builder | Cybersecurity & Cloud Enthusiast**

I build practical software systems while exploring backend engineering, cloud infrastructure, cybersecurity, developer tooling and AI.

## What I'm building

- **Joseph Garage** — a personal software development and cloud platform for building, containerizing, deploying and tracking projects.
- **Nexus** — an AI-powered developer platform bringing coding assistance, debugging, cloud tools, blockchain resources and project management into one workspace.
- **NetReconX** — an authorized network reconnaissance and security assessment platform focused on asset discovery, TCP reconnaissance, service identification, analysis and reporting.
- **SchemaLens** — a developer/data tooling project exploring easier schema inspection and understanding.
- **NIBS TechHub** — a student-led technology community I founded at NIBS for practical learning, coding sessions, hackathons and tech talks.

## Technical interests

Python · JavaScript · HTML · CSS · FastAPI · APIs · Linux · Docker · Git · GitHub · CI/CD · Networking · Cybersecurity · Cloud · AI/ML

## Engineering approach

**Understand → Design → Build → Test → Improve**

I care about clear system boundaries, useful documentation, controlled testing and measurable results.

## Portfolio

[Portfolio](https://github.com/merlin1235)

## Contact

- Email: `jkala863@gmail.com`
- Instagram: [@_merli.n](https://www.instagram.com/_merli.n/)
